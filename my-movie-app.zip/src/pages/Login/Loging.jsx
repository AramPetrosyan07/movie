import "./Loging.css";

const Loging = () => {
  return <div>Loging</div>;
};

export default Loging;
