import "./Cart.css";

const Cart = ({ movie }) => {
  return (
    <div
      className="cart"
      style={{
        backgroundImage: `url("${movie.image}")`,
      }}
    >
      <h3>{movie.name}</h3>
      <h3>{movie.id}</h3>
      <h3>{movie.reiting}</h3>
    </div>
  );
};

export default Cart;
